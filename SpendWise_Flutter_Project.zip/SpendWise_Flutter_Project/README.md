# SpendWise — Personal Expenses Tracker

A beginner-friendly Flutter/Dart mobile application for recording personal expenses and viewing spending summaries.

## Features
- Dashboard with total recorded expenses
- Transaction count and daily average
- Add an expense with a name, amount, and category
- Categories: Food, Transport, Bills, Shopping, Health, Education, and Other
- Recent expenses and full transaction history
- Nigerian naira (₦) currency display

## Requirements
- Flutter SDK installed
- Android Studio or Visual Studio Code
- Android emulator or a connected Android phone

## Run this project
This ZIP contains the Flutter application source code. To generate the Android and other platform runner folders on the computer that will run it:

1. Extract `SpendWise_Flutter_Project.zip`.
2. Open the extracted `SpendWise_Flutter_Project` folder in VS Code.
3. Open the terminal in that folder.
4. Run:
   ```bash
   flutter create .
   flutter pub get
   flutter run
   ```
5. Select an Android emulator or connected phone if Flutter asks.

If Flutter reports that a platform already exists, continue with `flutter pub get` and `flutter run`.

## Screenshots to capture
1. Home dashboard showing the total expenses.
2. Add expense form.
3. Dashboard after saving a new sample expense.
4. Transaction history screen.

## Important project note
This first version stores transactions in memory only. Added sample expenses reset when the app is closed. Persistent local storage can be added as a later enhancement.
