import 'package:flutter/material.dart';

void main() => runApp(const SpendWiseApp());

class SpendWiseApp extends StatelessWidget {
  const SpendWiseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SpendWise',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B5B)),
        scaffoldBackgroundColor: const Color(0xFFF5F7F6),
        fontFamily: 'Roboto',
      ),
      home: const ExpenseHomePage(),
    );
  }
}

class Expense {
  Expense(this.title, this.category, this.amount, this.date);
  final String title;
  final String category;
  final double amount;
  final DateTime date;
}

class ExpenseHomePage extends StatefulWidget {
  const ExpenseHomePage({super.key});

  @override
  State<ExpenseHomePage> createState() => _ExpenseHomePageState();
}

class _ExpenseHomePageState extends State<ExpenseHomePage> {
  int _tab = 0;
  final List<Expense> _expenses = [
    Expense('Groceries', 'Food', 8500, DateTime.now()),
    Expense('Bus fare', 'Transport', 2500, DateTime.now()),
    Expense('Mobile data', 'Bills', 3000, DateTime.now()),
  ];

  double get _total => _expenses.fold(0, (sum, item) => sum + item.amount);
  String _money(double value) => '₦${value.toStringAsFixed(2)}';

  void _addExpense(String title, String category, double amount) {
    setState(() {
      _expenses.insert(0, Expense(title, category, amount, DateTime.now()));
      _tab = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFFF5F7F6),
        title: const Row(
          children: [
            Icon(Icons.account_balance_wallet_rounded, color: Color(0xFF176B5B)),
            SizedBox(width: 9),
            Text('SpendWise', style: TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Notifications',
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: _tab == 0 ? _dashboard() : _history(),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddExpense,
        backgroundColor: const Color(0xFF176B5B),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('Add expense'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'History'),
        ],
      ),
    );
  }

  Widget _dashboard() {
    final now = DateTime.now();
    final monthName = [
      'January','February','March','April','May','June',
      'July','August','September','October','November','December'
    ][now.month - 1];

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 100),
      children: [
        Text('Good day 👋', style: TextStyle(color: Colors.grey.shade700, fontSize: 15)),
        const SizedBox(height: 4),
        const Text('Here is your spending overview', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF176B5B), Color(0xFF24947B)]),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('TOTAL EXPENSES', style: TextStyle(color: Colors.white70, letterSpacing: 1.2, fontSize: 12)),
            const SizedBox(height: 8),
            Text(_money(_total), style: const TextStyle(color: Colors.white, fontSize: 31, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(children: [
              const Icon(Icons.calendar_month, color: Colors.white70, size: 17),
              const SizedBox(width: 6),
              Text('$monthName ${now.year}', style: const TextStyle(color: Colors.white70)),
              const Spacer(),
              const Icon(Icons.trending_up, color: Colors.white),
              const Text('  Track your money', style: TextStyle(color: Colors.white)),
            ]),
          ]),
        ),
        const SizedBox(height: 20),
        Row(children: [
          _summaryCard('Transactions', '${_expenses.length}', Icons.receipt_long, const Color(0xFFE8F2EF)),
          const SizedBox(width: 12),
          _summaryCard('Daily average', _money(_total / (now.day == 0 ? 1 : now.day)), Icons.insights, const Color(0xFFFFF1DF)),
        ]),
        const SizedBox(height: 24),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Recent expenses', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('See all')),
        ]),
        if (_expenses.isEmpty)
          const Padding(
            padding: EdgeInsets.all(28),
            child: Center(child: Text('No expenses yet. Tap “Add expense” to begin.')),
          )
        else
          ..._expenses.take(5).map(_expenseTile),
      ],
    );
  }

  Widget _summaryCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(backgroundColor: color, child: Icon(icon, color: const Color(0xFF176B5B))),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 3),
          Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
        ]),
      ),
    );
  }

  Widget _history() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 100),
      children: [
        const Text('Transaction history', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text('All your recorded expenses in one place', style: TextStyle(color: Colors.grey.shade600)),
        const SizedBox(height: 18),
        if (_expenses.isEmpty)
          const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('No transactions recorded yet.')))
        else
          ..._expenses.map(_expenseTile),
      ],
    );
  }

  Widget _expenseTile(Expense expense) {
    final icons = {
      'Food': Icons.restaurant,
      'Transport': Icons.directions_bus,
      'Bills': Icons.receipt,
      'Shopping': Icons.shopping_bag,
      'Health': Icons.health_and_safety,
      'Education': Icons.school,
      'Other': Icons.category,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
      child: Row(children: [
        CircleAvatar(
          backgroundColor: const Color(0xFFE8F2EF),
          child: Icon(icons[expense.category] ?? Icons.category, color: const Color(0xFF176B5B)),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(expense.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('${expense.category} • ${expense.date.day}/${expense.date.month}/${expense.date.year}',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
        ])),
        Text('- ${_money(expense.amount)}', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFB5473C))),
      ]),
    );
  }

  void _showAddExpense() {
    final formKey = GlobalKey<FormState>();
    final titleController = TextEditingController();
    final amountController = TextEditingController();
    String category = 'Food';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: EdgeInsets.fromLTRB(20, 22, 20, MediaQuery.of(context).viewInsets.bottom + 24),
          child: Form(
            key: formKey,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Add new expense', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 18),
              TextFormField(
                controller: titleController,
                decoration: const InputDecoration(labelText: 'Expense name', hintText: 'e.g. Lunch', border: OutlineInputBorder()),
                validator: (value) => value == null || value.trim().isEmpty ? 'Enter an expense name' : null,
              ),
              const SizedBox(height: 13),
              TextFormField(
                controller: amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(labelText: 'Amount (₦)', hintText: 'e.g. 2500', border: OutlineInputBorder()),
                validator: (value) {
                  final amount = double.tryParse(value ?? '');
                  return amount == null || amount <= 0 ? 'Enter a valid amount' : null;
                },
              ),
              const SizedBox(height: 13),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
                items: ['Food', 'Transport', 'Bills', 'Shopping', 'Health', 'Education', 'Other']
                    .map((item) => DropdownMenuItem(value: item, child: Text(item))).toList(),
                onChanged: (value) => setSheetState(() => category = value ?? 'Food'),
              ),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF176B5B), padding: const EdgeInsets.symmetric(vertical: 15)),
                onPressed: () {
                  if (formKey.currentState!.validate()) {
                    _addExpense(titleController.text.trim(), category, double.parse(amountController.text));
                    Navigator.pop(sheetContext);
                  }
                },
                child: const Text('Save expense'),
              )),
            ]),
          ),
        ),
      ),
    );
  }
}
